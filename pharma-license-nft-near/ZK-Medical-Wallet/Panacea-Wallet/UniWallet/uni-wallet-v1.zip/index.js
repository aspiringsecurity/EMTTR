console.log('Welcome To UniWallet v1.0');

const express = require('express');


const walletVault= require('./wallet-vault');
const sendTx = require('./sendTx');

const app = express();
const port = process.env.PORT || 8080;

let privKeyData = walletVault.privKeyData();
let keyIndex = 0;

// routes will go here
app.get('/testWallet', function(req, res) {
    res.send('UniWallet');
});

app.get('/tx/sendTransaction',(req,res)=>{
    try{
        sendTx.setKeys(privKeyData[keyIndex].addr,privKeyData[keyIndex].privkey);
        if(req.param('accountToTransfer')){
            let t = sendTx.sendTransaction(req.param('accountToTransfer'));
            res.send("Worked");
        }else{
              res.send("Something went wrong!")
        }
    }catch(e){
        console.log('Keys are not Set');
        res.send('Keys are not Set');
    }
    
})
  // start the server
app.listen(port);
console.log('Server started! At http://localhost:' + port);